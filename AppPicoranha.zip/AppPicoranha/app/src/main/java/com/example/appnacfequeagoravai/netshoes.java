package com.example.appnacfequeagoravai;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class netshoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_netshoes);

        WebView webviewNetshoes = findViewById(R.id.webviewNetshoes);
        webviewNetshoes.setWebViewClient(new WebViewClient());

        webviewNetshoes.getSettings().setJavaScriptEnabled(true);

        webviewNetshoes.loadUrl("https://www.netshoes.com.br");
    }
}
